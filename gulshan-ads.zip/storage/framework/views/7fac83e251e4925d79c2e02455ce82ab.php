<?php $__env->startSection('content'); ?>
	 <h6 class="mb-0 text-uppercase">Edit Ad Account TopUp Balance</h6>
	<hr/>
	<div class="row">
		<div class="col-xl-8 mx-auto">		
			<div class="card">
              <div class="card-body">
                <div class="border p-3 rounded">
                <h6 class="mb-0 text-uppercase">Edit Ad Account TopUp Balance  - <?php echo e($adAccountTopUpData->adAccountData->ad_name); ?>(<?php echo e($adAccountTopUpData->adAccountData->ad_account_number); ?>) </h6>
                <hr/>

                <form class="row g-3" action="<?php echo e(route('ad-account-top-up-request-update',$adAccountTopUpData->id)); ?>" method="post">
                <?php echo csrf_field(); ?>

                  <div class="col-12">
                    <label class="form-label">Amount</label>
                    <input type="number" class="form-control" name="amount" value="<?php echo e($adAccountTopUpData->amount); ?>" required>
                  </div>

                  <div class="col-12">
                    <label class="form-label">Note</label>
                    <input type="text" class="form-control" name="note" value="<?php echo e($adAccountTopUpData->note); ?>">
                  </div>

                  <div class="col-12">
                    <div class="">
                      <button type="submit" class="btn btn-primary">Update</button>
                    </div>
                  </div>

                </form>

              </div>
              </div>
            </div>

		</div>
	</div>
	<!--end row-->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\p project\ads\ads-agency\resources\views/admin/adAccount/adAccountTopUpRequestEdit.blade.php ENDPATH**/ ?>