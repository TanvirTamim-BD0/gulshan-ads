<?php $__env->startSection('content'); ?>
	 <h6 class="mb-0 text-uppercase">Edit Role</h6>
	<hr/>
	<div class="row">
		<div class="col-xl-10 mx-auto">		
			<div class="card">
              <div class="card-body">
                <div class="border p-3 rounded">
                <h6 class="mb-0 text-uppercase">Edit Role</h6>
                <hr/>

                <form class="row g-3" action="<?php echo e(route('role.update',$role->id)); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('put'); ?>

                <div class="col-12">
                    <label class="form-label">Role Name</label>
                    <input type="text" name="name" value="<?php echo e($role->name); ?>" class="form-control" required>
                  </div>


                  <br><br>

                  <h5>Permissions</h5>

                  <br>

                  <table>
                    <?php $i = 1; ?>
                    <tr>
                      <td><label class="form-check form-check-custom form-check-solid me-9"
                            for="checkPermissionAll">
                            <input class="form-check-input" type="checkbox" value="1"
                              <?php echo e(App\Models\Admin::roleHasPermissions($role, $all_permissions) ? 'checked' : ''); ?> 
                              onclick="checkPermissionByGroup('role-<?php echo e($i); ?>-management-checkbox', this)"
                              id="checkPermissionAll" />
                            <span class="form-check-label">Select all</span>
                          </label></td>
                    </tr>


                    <tr>
                      <td>
                        
                        <div class="role-<?php echo e($i); ?>-management-checkbox">
                        <?php $__currentLoopData = $all_permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <label
                              class="form-check form-check-sm form-check-custom form-check-solid me-2 me-lg-20 mt-1"
                              for="<?php echo e($permission->id); ?>">

                              <input class="form-check-input" type="checkbox"
                                name="permission[]" value="<?php echo e($permission->name); ?>"
                                id="<?php echo e($permission->id); ?>"
                                <?php echo e($role->hasPermissionTo($permission->name) ? 'checked' : ''); ?>>

                              <span
                                class="form-check-label"><?php echo e(Str::title($permission->name)); ?></span>
                            </label>
                           
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </div>
                      </td>
                    </tr>
                    <?php $i++; ?>

                  </table>


                   <div class="col-12">
                    <div class="">
                      <button type="submit" class="btn btn-primary">Update Role</button>
                    </div>
                  </div>

                </form>

              </div>
              </div>
            </div>

		</div>
	</div>
	<!--end row-->

  <script>
    function checkPermissionByGroup(className, checkThis){
            const groupIdName = $("#"+checkThis.id);
            const classCheckBox = $('.'+className+' input');

            if(groupIdName.is(':checked')){
                 classCheckBox.prop('checked', true);
             }else{
                 classCheckBox.prop('checked', false);
             }
         }
  </script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\p project\ads\ads-agency\resources\views/admin/roles/edit.blade.php ENDPATH**/ ?>