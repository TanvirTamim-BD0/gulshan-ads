<?php $__env->startSection('content'); ?>

	<div class="row ">

                    <div class="col-md-4">
                        <div class="card rounded-4">
                            <div class="card-body">
                                <div class="d-flex align-items-center">
                                    <div class="">
                                        <p class="mb-1">Total Accounts</p>
                                        <h4 class="mb-0"><?php echo e($accountCount); ?></h4>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="card rounded-4">
                            <div class="card-body">
                                <div class="d-flex align-items-center">
                                    <div class="">
                                        <p class="mb-1">Total Deposit Amount</p>
                                        <h4 class="mb-0">$<?php echo e($totalDepositAmount); ?></h4>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="card rounded-4">
                            <div class="card-body">
                                <div class="d-flex align-items-center">
                                    <div class="">
                                        <p class="mb-1">Total Service Purchase</p>
                                        <h4 class="mb-0"><?php echo e($buyServiceCount); ?></h4>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="card rounded-4">
                            <div class="card-body">
                                <div class="d-flex align-items-center">
                                    <div class="">
                                        <p class="mb-1">Total BM Share</p>
                                        <h4 class="mb-0"><?php echo e($bmShareCount); ?></h4>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="card rounded-4">
                            <div class="card-body">
                                <div class="d-flex align-items-center">
                                    <div class="">
                                        <p class="mb-1">Total Account Disabled</p>
                                        <h4 class="mb-0"><?php echo e($disabledCount); ?></h4>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>


                    <div class="col-md-4">
                        <div class="card rounded-4">
                            <div class="card-body">
                                <div class="d-flex align-items-center">
                                    <div class="">
                                        <p class="mb-1">Total Replace</p>
                                        <h4 class="mb-0"><?php echo e($replaceCount); ?></h4>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-4">
                        <div class="card rounded-4">
                            <div class="card-body">
                                <div class="d-flex align-items-center">
                                    <div class="">
                                        <p class="mb-1">Total Campaign</p>
                                        <h4 class="mb-0"><?php echo e($campaignCount); ?></h4>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                
                </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\p project\ads\ads-agency\resources\views/user/adAccount/overview.blade.php ENDPATH**/ ?>