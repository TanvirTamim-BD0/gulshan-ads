
<?php $__env->startSection('content'); ?>
    <h6 class="mb-0 text-uppercase">Ad Account BM Link Request</h6>
				<hr/>

				<div class="card">
					<div class="card-body">
						<div class="table-responsive">
							
							<table id="example" class="table table-striped table-bordered" style="width:100%">
								<thead>
									<tr>
										<th></th>
										<th>SL</th>
										<th>User</th>
										<th>BM Name</th>
										<th>Reply</th>
										<th class="text-center">Status</th>
										<th>Action</th>
									</tr>
								</thead>
								<tbody>

									<?php $__currentLoopData = $adAccountBMLinkData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adAccount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php if(isset($adAccount)): ?>
									<tr>
										<td>
											<a href="<?php echo e(route('ad-account-refund-request-delete',$adAccount->id)); ?>" class="text-danger" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete"><i class="bi bi-archive-fill"></i></a>
										</td>
										<td><?php echo e($loop->iteration); ?></td>
										<td><?php echo e($adAccount->userData->name); ?> (<?php echo e($adAccount->userData->userID); ?>)</td>

										<td><?php echo e($adAccount->bm_name); ?></td>
										<td><?php echo e($adAccount->reply); ?></td>

										<?php if($adAccount->status == 'Complete'): ?>
										<td class="text-center"><span class="badge bg-success text-white" style="padding: 10px;"> Complete </span></td>
										<?php else: ?>
										<td class="text-center"><span class="badge bg-warning text-white" style="padding: 10px;"> Pending </span></td>
										<?php endif; ?>
										
										<td>
				                            <div class="table-actions  fs-6">
				                            <?php if($adAccount->status == 'Complete'): ?>
				                            <?php else: ?>
				                            <a href="javascript:;" data-bs-toggle="modal"
	                                        data-bs-target="#rejectedData<?php echo e($adAccount->id); ?>"  class="btn btn-sm btn-primary" style="margin-top: 5px;" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Reply"><i class="bi bi-reply"></i> Reply</a><br>
	                                        <?php endif; ?>

	                                        <br>
	                                        
				                            </div>
				                         </td>

									</tr>

									<!-- Rejected Text -->
                                    <div class="modal fade" id="rejectedData<?php echo e($adAccount->id); ?>" tabindex="-1"
                                        aria-labelledby="usd_detailsLabel" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <form action="<?php echo e(route('ad-account-bm-link-reply',$adAccount->id)); ?>" method="post">
                                                <?php echo csrf_field(); ?>	
                                               	<div class="modal-header">
                                                    <h5 class="modal-title" id="usd_detailsLabel">Reply</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                        aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="row">
                                                        <div class="col-md-12 col-lg-12">
                                                            	<textarea class="form-control" cols="20" rows="5" name="reply">
                                                            		
                                                            	</textarea>
                                                        </div>
                                                        
                                                    </div>
                                                </div>

                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary"
                                                        data-bs-dismiss="modal">Close</button>
                                                     <button type="submit" class="btn btn-primary"
                                                        data-bs-dismiss="modal">Submit</button>
                                                </div>

                                                </form>
                                            </div>
                                        </div>
                                    </div>

                                    <?php endif; ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									
								</tbody>
								
							</table>
						</div>
					</div>
				</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\p project\ads\ads-agency\resources\views/admin/adAccount/adAccountBMLinkRequest.blade.php ENDPATH**/ ?>