<?php $__env->startSection('content'); ?>
    <h6 class="mb-0 text-uppercase">Guides List</h6>
				<hr/>

				<div align="right">
					<a href="<?php echo e(route('guide.create')); ?>" class="btn btn-primary">Add Guides</a>
				</div><br>

				<div class="card">
					<div class="card-body">
						<div class="table-responsive">
							<table id="example" class="table table-striped table-bordered" style="width:100%">
								<thead>
									<tr>
										<th>SL</th>
										<th>Image</th>
										<th>Title</th>
										<th>Action</th>
									</tr>
								</thead>
								<tbody>

									<?php $__currentLoopData = $guidesData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $guides): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php if(isset($guides)): ?>
									<tr>
										<td><?php echo e($loop->iteration); ?></td>
										<td class="text-center"><img src="<?php echo e(asset('/uploads/guides_image/'.$guides->image)); ?>" width="65" height="55" alt=""></td>
										<td><?php echo e($guides->title); ?></td>
										<td>
				                            <div class="table-actions  fs-6">
											  
											  <a href="<?php echo e(route('guide-view',$guides->id)); ?>" class="text-primary" data-bs-toggle="tooltip" data-bs-placement="bottom" title="View"><i class="bi bi-eye"></i> View</a><br>

											  <form method="POST" action="<?php echo e(route('guide.destroy', $guides->id)); ?>"
                                               >
                                              <?php echo csrf_field(); ?>
                                              <?php echo method_field('delete'); ?>
				                          
				                              <button type="submit" title="delete" id="show_confirm" class="bg-transparent border-0 text-danger" style="margin-left: -8px;"> <span><i class="bi bi-trash"></i> Delete</span>
                                           	  </button> <br>
				                              </form>

				                              <a href="<?php echo e(route('guide.edit',$guides->id)); ?>" class="text-success" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit"><i class="bi bi-pencil-square"></i> Edit</a>

				                            </div>
				                         </td>

									</tr>
									<?php endif; ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

								</tbody>
								
							</table>
						</div>
					</div>
				</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\p project\ads\ads-agency\resources\views/admin/guides/index.blade.php ENDPATH**/ ?>