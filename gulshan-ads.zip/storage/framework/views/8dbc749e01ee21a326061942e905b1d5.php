<?php $__env->startSection('content'); ?>
	 <h6 class="mb-0 text-uppercase">Add Admin</h6>
	<hr/>
	<div class="row">
		<div class="col-xl-8 mx-auto">		
			<div class="card">
              <div class="card-body">
                <div class="border p-3 rounded">
                <h6 class="mb-0 text-uppercase">Add Admin</h6>
                <hr/>

                <form class="row g-3" action="<?php echo e(route('admins.store')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>


                <div class="col-12">
                    <label class="form-label">Name</label>
                    <input type="text" name="name" class="form-control" required>
                  </div>

                  <div class="col-12">
                    <label class="form-label">Email</label>
                    <input type="text" name="email" class="form-control" required>
                  </div>

                  <div class="col-12">
                  <label class="form-label">Role</label>
                    <select class="single-select" name="roles" required>
                      <option selected disabled>Select Role</option>
                      <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if(isset($role)): ?>
                      <option value="<?php echo e($role->name); ?>"><?php echo e(Str::title($role->name)); ?></option>
                      <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>           
                    </select>
                  </div>

                  <div class="col-12">
                    <label class="form-label">Password</label>
                    <input type="password" name="password" class="form-control" required>
                  </div>

                  <div class="col-12">
                    <div class="">
                      <button type="submit" class="btn btn-primary">Add Admin</button>
                    </div>
                  </div>

                </form>

              </div>
              </div>
            </div>

		</div>
	</div>
	<!--end row-->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\p project\ads\ads-agency\resources\views/admin/admins/create.blade.php ENDPATH**/ ?>