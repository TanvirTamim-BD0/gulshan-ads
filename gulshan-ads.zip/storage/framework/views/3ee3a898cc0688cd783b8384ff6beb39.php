<?php $__env->startSection('content'); ?>
    <h6 class="mb-0 text-uppercase">Ad Account Disabled Request</h6>
				<hr/>

				<div class="card">
					<div class="card-body">
						<div class="table-responsive">

							<div align="right">
								<!-- <a href="<?php echo e(route('ad-account-appeal-status-filter','Complete')); ?>" class="btn btn-success">Complete</a> -->

								<a href="<?php echo e(route('ad-account-appeal-status-filter','Reject')); ?>" class="btn btn-danger">Rejected</a>

								<a href="<?php echo e(route('ad-account-appeal-status-filter','Pending')); ?>" class="btn btn-warning">Under Review</a>
							</div><br>
							
							<table id="example" class="table table-striped table-bordered" style="width:100%">
								<thead>
									<tr>
										<th></th>
										<th>SL</th>
										<th>User</th>
										<th>Ad Account</th>
										<th>Confirmed Date</th>
										<th class="text-center">Status</th>
										<th>Action</th>
									</tr>
								</thead>
								<tbody>

									<?php $__currentLoopData = $adAccountAppealData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adAccount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php if(isset($adAccount)): ?>
									<tr>
										<td>
											<a href="<?php echo e(route('ad-account-appeal-request-delete',$adAccount->id)); ?>" class="text-danger" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete"><i class="bi bi-archive-fill"></i></a>	
										</td>
										<td><?php echo e($loop->iteration); ?></td>
										<td><?php echo e($adAccount->userData->name); ?> (<?php echo e($adAccount->userData->userID); ?>)</td>
										<td><?php echo e($adAccount->adAccountData->ad_name); ?> (<?php echo e($adAccount->adAccountData->ad_account_number); ?>)</td>
										<td><?php echo e($adAccount->confirmed_date); ?></td>
									
										
										<?php if($adAccount->status == 'Reject'): ?>
										<td class="text-center"><span class="badge bg-danger text-white" style="padding: 10px;"> Rejected </span></td>
										<?php else: ?>
										<td class="text-center"><span class="badge bg-warning text-white" style="padding: 10px;"> Under review </span></td>
										<?php endif; ?>
										
										<td>
				                            <div class="table-actions  fs-6">
				                            
 
				                            <?php if($adAccount->status == 'Reject'): ?>
				                            <?php else: ?>
				                            <a href="javascript:;" data-bs-toggle="modal"
	                                        data-bs-target="#rejectedData<?php echo e($adAccount->id); ?>"  class="btn btn-sm btn-danger" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Reject"><i class="bi bi-file-earmark-x"></i> Rejected</a><br>
	                                        <?php endif; ?>
	                                        
	                                        <br>

				                            </div>

				                         </td>

									</tr>

									<!-- Rejected Text -->
                                    <div class="modal fade" id="rejectedData<?php echo e($adAccount->id); ?>" tabindex="-1"
                                        aria-labelledby="usd_detailsLabel" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <form action="<?php echo e(route('ad-account-appeal-request-reject',$adAccount->id)); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="ad_account_appeal_id" value="<?php echo e($adAccount->id); ?>">
                                               	<div class="modal-header">
                                                    <h5 class="modal-title" id="usd_detailsLabel">Rejected Text</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                        aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="row">
                                                        <div class="col-md-12 col-lg-12">
                                                            	<textarea class="form-control" cols="20" rows="5" name="rejected_text">
                                                            		
                                                            	</textarea>
                                                        </div>
                                                        
                                                    </div>
                                                </div>

                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary"
                                                        data-bs-dismiss="modal">Close</button>
                                                     <button type="submit" class="btn btn-primary"
                                                        data-bs-dismiss="modal">Submit</button>
                                                </div>

                                                </form>
                                            </div>
                                        </div>
                                    </div>

									<?php endif; ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

								</tbody>
								
							</table>
						</div>
					</div>
				</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\p project\ads\ads-agency\resources\views/admin/adAccount/adAccountAppealRequest.blade.php ENDPATH**/ ?>