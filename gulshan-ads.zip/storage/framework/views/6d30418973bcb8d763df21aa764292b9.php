<?php $__env->startSection('content'); ?>
    <h6 class="mb-0 text-uppercase">Ad Account Limit Request</h6>
				<hr/>

				<div class="card">
					<div class="card-body">
						<div class="table-responsive">

							<div align="right">
								<a href="<?php echo e(route('ad-account-topup-status-filter','Complete')); ?>" class="btn btn-success">Complete</a>

								<a href="<?php echo e(route('ad-account-topup-status-filter','Reject')); ?>" class="btn btn-danger">Reject</a>

								<a href="<?php echo e(route('ad-account-topup-status-filter','Pending')); ?>" class="btn btn-warning">Pending</a>
							</div><br>
							
							<table id="example" class="table table-striped table-bordered" style="width:100%">
								<thead>
									<tr>
										<th></th>
										<th>SL</th>
										<th>User</th>
										<th>Ad Account</th>
										<th>Exist Balance</th>
										<th>TopUp Amount</th>
										<th>Note</th>
										<th>Complete Date</th>
										<th class="text-center">Status</th>
										<th>Action</th>
									</tr>
								</thead>
								<tbody>

									<?php $__currentLoopData = $adAccountTopUpData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adAccount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php if(isset($adAccount)): ?>
									<tr>
										<td>
											<a href="<?php echo e(route('ad-account-top-up-request-delete',$adAccount->id)); ?>" class="text-danger" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete"><i class="bi bi-archive-fill"></i></a>

										</td>
										<td><?php echo e($loop->iteration); ?></td>
										<td><?php echo e($adAccount->userData->name); ?> (<?php echo e($adAccount->userData->userID); ?>)</td>
										<td><?php echo e($adAccount->adAccountData->ad_name); ?> (<?php echo e($adAccount->adAccountData->ad_account_number); ?>)</td>
										<td><?php echo e($adAccount->userData->balance); ?></td>
										<td><?php echo e($adAccount->amount); ?></td>
										<td><?php echo e($adAccount->note); ?></td>
										<td><?php echo e($adAccount->confirmed_date); ?></td>

										<?php if($adAccount->status == 'Complete'): ?>
										<td class="text-center"><span class="badge bg-success text-white" style="padding: 10px;"> Complete </span></td>
										<?php elseif($adAccount->status == 'Reject'): ?>
										<td class="text-center"><span class="badge bg-danger text-white" style="padding: 10px;"> Reject </span></td>
										<?php else: ?>
										<td class="text-center"><span class="badge bg-warning text-white" style="padding: 10px;"> Pending </span></td>
										<?php endif; ?>
										
										<td>
				                            <div class="table-actions  fs-6">
				                            <?php if($adAccount->status == 'Complete'): ?>
				                        	<?php else: ?>
				                            <a href="<?php echo e(route('ad-account-top-up-request-complete',$adAccount->id)); ?>" class="btn btn btn-sm btn-success" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Complete"><i class="bi bi-check-circle"></i> Complete</a><br>
				                            <?php endif; ?>
 
				                            <?php if($adAccount->status == 'Reject'): ?>
				                            <?php else: ?>
				                            <a href="<?php echo e(route('ad-account-top-up-request-reject',$adAccount->id)); ?>" style="margin-top: 5px;"  class="btn btn-sm btn-danger"><i class="bi bi-file-earmark-x"></i> Reject</a><br>
	                                        <?php endif; ?>

	                                        <a href="<?php echo e(route('ad-account-top-up-request-edit',$adAccount->id)); ?>" style="margin-top: 5px;" class="btn btn-sm btn-primary" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit"><i class="bi bi-pencil-square"></i> Edit</a><br>

	                                        <br>

	                                        
				                            </div>
				                         </td>

									</tr>


							

									<?php endif; ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

								</tbody>
								
							</table>
						</div>
					</div>
				</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\p project\ads\ads-agency\resources\views/admin/adAccount/adAccountTopUpRequest.blade.php ENDPATH**/ ?>