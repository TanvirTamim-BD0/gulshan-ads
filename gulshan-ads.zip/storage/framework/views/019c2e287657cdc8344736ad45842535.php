<?php $__env->startSection('content'); ?>
	 <h6 class="mb-0 text-uppercase">Update Support</h6>
	<hr/>
	<div class="row">
		<div class="col-xl-8 mx-auto">		
			<div class="card">
              <div class="card-body">
                <div class="border p-3 rounded">
                <h6 class="mb-0 text-uppercase">Update Support</h6>
                <hr/>

                <form class="row g-3" action="<?php echo e(route('supports.update',$supportData->id)); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('put'); ?>

                <div class="col-12">
                    <label class="form-label">Title</label>
                    <input type="text" name="title" class="form-control" value="<?php echo e($supportData->title); ?>" required>
                  </div>

                  <div class="col-12">
                    <label class="form-label">Description</label>
                    <textarea class="form-control" name="description" id="description"><?php echo e($supportData->description); ?></textarea>
                  </div>

                  <div class="col-12">
                    <div class="">
                      <button type="submit" class="btn btn-primary">Update Support</button>
                    </div>
                  </div>

                </form>

              </div>
              </div>
            </div>

		</div>
	</div>
	<!--end row-->

  <script src="https://cdn.ckeditor.com/ckeditor5/23.0.0/classic/ckeditor.js"></script>
   <style>.ck-editor__editable_inline {height: 200px;}</style>
  <script>
            ClassicEditor.create( document.querySelector( '#content' ) )
                .catch( error => {
                    console.error( error );
                } );
        </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\p project\ads\ads-agency\resources\views/admin/support/edit.blade.php ENDPATH**/ ?>