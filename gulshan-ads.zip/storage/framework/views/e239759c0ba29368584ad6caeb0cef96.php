<?php $__env->startSection('content'); ?>
    <h6 class="mb-0 text-uppercase">Admin List</h6>
				<hr/>

				<div align="right">
					<a href="<?php echo e(route('admins.create')); ?>" class="btn btn-primary">Add Admin</a>
				</div><br>

				<div class="card">
					<div class="card-body">
						<div class="table-responsive">
							<table id="example" class="table table-striped table-bordered" style="width:100%">
								<thead>
									<tr>
										<th>SL</th>
										<th>Name</th>
										<th>Email</th>
										<th>Role</th>
										<th>Action</th>
									</tr>
								</thead>
								<tbody>

									<?php $__currentLoopData = $adminData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php if(isset($admin)): ?>
									<tr>
										<td><?php echo e($loop->iteration); ?></td>
										<td><?php echo e($admin->name); ?></td>
										<td><?php echo e($admin->email); ?></td>

										<td>
										<?php $__currentLoopData = $admin->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<span class="badge mt-2" style="background-color: #0d6efd; color: white; padding: 4px 8px; text-align: center; border-radius: 5px;">
											<?php echo e($role->name); ?>

										</span>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</td>

										<td>
											<?php if(Auth::guard('admin')->user()->email == 'khaledhasanit@gmail.com'): ?>
				                            <div class="table-actions  fs-6">
											  
											  <form method="POST" action="<?php echo e(route('admins.destroy', $admin->id)); ?>"
                                               >
                                              <?php echo csrf_field(); ?>
                                              <?php echo method_field('delete'); ?>
				                          
				                              <button type="submit" title="delete" id="show_confirm" class="bg-transparent border-0 text-danger" style="margin-left: -8px;"> <span><i class="bi bi-trash"></i> Delete</span>
                                           	  </button> <br>
				                              </form>
				                            

				                              <a href="<?php echo e(route('admins.edit',$admin->id)); ?>" class="text-success" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit"><i class="bi bi-pencil-square"></i> Edit</a>

				                            </div>
				                            <?php else: ?>
				                            <?php endif; ?>
				                         </td>

									</tr>
									<?php endif; ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

								</tbody>
								
							</table>
						</div>
					</div>
				</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\p project\ads\ads-agency\resources\views/admin/admins/index.blade.php ENDPATH**/ ?>