
<!DOCTYPE html>
<html lang="en" class="semi-dark">
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="<?php echo e(asset('admin')); ?>/assets/images/favicon-32x32.png" type="image/png" />
        <!--plugins-->
        <link href="<?php echo e(asset('admin')); ?>/assets/plugins/simplebar/css/simplebar.css" rel="stylesheet" />
        <link href="<?php echo e(asset('admin')); ?>/assets/plugins/perfect-scrollbar/css/perfect-scrollbar.css" rel="stylesheet" />
        <link href="<?php echo e(asset('admin')); ?>/assets/plugins/metismenu/css/metisMenu.min.css" rel="stylesheet" />
        <!-- Bootstrap CSS -->
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <link href="<?php echo e(asset('admin')); ?>/assets/css/bootstrap.min.css" rel="stylesheet" />
        <link href="<?php echo e(asset('admin')); ?>/assets/css/bootstrap-extended.css" rel="stylesheet" />
        <link href="<?php echo e(asset('admin')); ?>/assets/css/style.css" rel="stylesheet" />
        <link href="<?php echo e(asset('admin')); ?>/assets/css/icons.css" rel="stylesheet" />
        <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&display=swap" rel="stylesheet" />
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" />

        <!-- loader-->
        <link href="<?php echo e(asset('admin')); ?>/assets/css/pace.min.css" rel="stylesheet" />

        <!--Theme Styles-->
        <link href="<?php echo e(asset('admin')); ?>/assets/css/dark-theme.css" rel="stylesheet" />
        <link href="<?php echo e(asset('admin')); ?>/assets/css/light-theme.css" rel="stylesheet" />
        <link href="<?php echo e(asset('admin')); ?>/assets/css/semi-dark.css" rel="stylesheet" />
        <link href="<?php echo e(asset('admin')); ?>/assets/css/header-colors.css" rel="stylesheet" />
        <link href="<?php echo e(asset('admin')); ?>/assets/plugins/datatable/css/dataTables.bootstrap5.min.css" rel="stylesheet" />
        <link href="<?php echo e(asset('admin')); ?>/assets/plugins/select2/css/select2.min.css" rel="stylesheet" />
        <link href="<?php echo e(asset('admin')); ?>/assets/plugins/select2/css/select2-bootstrap4.css" rel="stylesheet" />
        
        <title>Dashboard</title>
    </head>

    <body>
        <!--start wrapper-->
        <div class="wrapper">

            <!--start top header-->
            <header class="top-header">
                <nav class="navbar navbar-expand gap-3">
                    <div class="mobile-toggle-icon fs-3">
                        <i class="bi bi-list"></i>
                    </div>

                    <h5><?php echo e(Auth::user()->name); ?> (<?php echo e(Auth::user()->userID); ?>)</h5>

                    <div class="top-navbar-right ms-auto">
                        <ul class="navbar-nav align-items-center">
                            <li class="nav-item dropdown dropdown-user-setting">
                                
                                <h5>Balance $<?php echo e(Auth::user()->balance); ?></h5>
                            </li>
                        </ul>
                    </div>


                    
                </nav>
            </header>
            <!--end top header-->

             <?php
                    $setting = App\Models\Ads::first();
                    ?>
                    

            <!--start sidebar -->
            <aside class="sidebar-wrapper" data-simplebar="true">
                <div class="sidebar-header">
                    <div>
                        <img src="<?php echo e(asset('/uploads/site_logo/'.$setting->site_logo)); ?>" class="logo-icon" alt="logo icon" />
                    </div>
                    <div>
                        <h4 class="logo-text"><?php echo e($setting->site_name); ?></h4>
                    </div>
                    <div class="toggle-icon ms-auto"><i class="bi bi-list"></i></div>
                </div>
                <!--navigation-->
                <ul class="metismenu" id="menu">

                    <li>
                        <a>
                            <div class="parent-icon"></div>
                            <h5 class="logo-text text-white">Balance $<?php echo e(Auth::user()->balance); ?></h5>
                        </a>
                    </li> 

                    <?php
                    $dollarRate = App\Models\DollarRate::first();
                    $ads = App\Models\Ads::first();
                    ?>

                    <li>
                        <a href="<?php echo e(route('home')); ?>">
                            <div class="parent-icon"><i class="bi bi-house-fill"></i></div>
                            <div class="menu-title">Home</div>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('balance')); ?>">
                            <div class="parent-icon"><i class="bi bi-droplet-fill"></i></div>
                            <div class="menu-title">Balance</div>
                        </a>
                    </li>

                    <li class="<?php echo e(request()->is('ad-account-edit*') ? 'mm-active' : ''); ?>">
                        <a href="javascript:;" class="has-arrow">
                            <div class="parent-icon"><i class="bi bi-grid-fill"></i></div>
                            <div class="menu-title">Meta Ad Accounts</div>
                        </a>
                        <ul>
                            <li>
                                <a href="<?php echo e(route('ad-account-overview')); ?>"><i class="bi bi-circle"></i>Overview</a>
                            </li>

                            <li>
                                <a href="<?php echo e(route('ad-account-request-list')); ?>"><i class="bi bi-circle"></i>Account Request List</a>
                            </li>

                            <li>
                                <a href="<?php echo e(route('created-account')); ?>"><i class="bi bi-circle"></i>Created Account</a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('ad-account-request')); ?>"><i class="bi bi-circle"></i>Account Request</a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('ad-account-top-up')); ?>"><i class="bi bi-circle"></i>Topup Limit</a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('ad-account-transfer')); ?>"><i class="bi bi-circle"></i>BM share/remove</a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('ad-account-appeal')); ?>"><i class="bi bi-circle"></i>Account Disabled</a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('ad-account-replace')); ?>"><i class="bi bi-circle"></i>Account Replace</a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('ad-account-rename')); ?>"><i class="bi bi-circle"></i>Account Rename</a>
                            </li>
                        </ul>
                    </li>

                    <li class="<?php echo e(request()->is('create-campaign*') ? 'mm-active' : ''); ?>">
                        <a href="javascript:;" class="has-arrow">
                            <div class="parent-icon"><i class="bi bi-calendar-week"></i></div>
                            <div class="menu-title">Campaign</div>
                        </a>
                        <ul>
                            <li>
                                <a href="<?php echo e(route('create-campaign')); ?>"><i class="bi bi-circle"></i>Create Campaign</a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('pending-campaign')); ?>"><i class="bi bi-circle"></i>Pending Campaign</a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('resume-campaign')); ?>"><i class="bi bi-circle"></i>Resume Campaign</a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('pause-campaign')); ?>"><i class="bi bi-circle"></i>Pause Campaign</a>
                            </li>
                        </ul>
                    </li>

                    <li>
                        <a href="<?php echo e(route('guides')); ?>">
                            <div class="parent-icon"><i class="bi bi-collection-play-fill"></i></div>
                            <div class="menu-title">Guides</div>
                        </a>
                    </li>

                    <li class="<?php echo e(request()->is('services*') ? 'mm-active' : ''); ?> <?php echo e(request()->is('service-buy-report') ? 'mm-active' : ''); ?>">
                        <a href="javascript:;" class="has-arrow">
                            <div class="parent-icon"><i class="bi bi-basket2-fill"></i></div>
                            <div class="menu-title">Services</div>
                        </a>
                        <ul>
                            <li>
                                <a href="<?php echo e(route('services')); ?>"><i class="bi bi-circle"></i>Services</a>
                            </li>

                            <li>
                                <a href="<?php echo e(route('service-buy-report')); ?>"><i class="bi bi-circle"></i>Service Buy Report</a>
                            </li>
                            
                        </ul>
                    </li>

                    <li class="<?php echo e(request()->is('balance-top-up-history') ? 'mm-active' : ''); ?> <?php echo e(request()->is('ad-account-top-up-history') ? 'mm-active' : ''); ?> <?php echo e(request()->is('transfer-history') ? 'mm-active' : ''); ?> <?php echo e(request()->is('appeal-history') ? 'mm-active' : ''); ?> <?php echo e(request()->is('replace-history') ? 'mm-active' : ''); ?> <?php echo e(request()->is('service-buy-history') ? 'mm-active' : ''); ?>">
                        <a href="javascript:;" class="has-arrow">
                            <div class="parent-icon"><i class="bi bi-stopwatch"></i></div>
                            <div class="menu-title">History</div>
                        </a>
                        <ul>
                            <li>
                                <a href="<?php echo e(route('balance-top-up-history')); ?>"><i class="bi bi-circle"></i>Balance TopUp History</a>
                            </li>

                            <li>
                                <a href="<?php echo e(route('ad-account-top-up-history')); ?>"><i class="bi bi-circle"></i>Ad Account TopUp History</a>
                            </li>

                            <li>
                                <a href="<?php echo e(route('transfer-history')); ?>"><i class="bi bi-circle"></i>Trasnfer History</a>
                            </li>

                            <li>
                                <a href="<?php echo e(route('appeal-history')); ?>"><i class="bi bi-circle"></i>Appeal History</a>
                            </li>

                            <li>
                                <a href="<?php echo e(route('replace-history')); ?>"><i class="bi bi-circle"></i>Replace History</a>
                            </li>

                            <li>
                                <a href="<?php echo e(route('rename-history')); ?>"><i class="bi bi-circle"></i>Rename History</a>
                            </li>

                            <li>
                                <a href="<?php echo e(route('service-buy-history')); ?>"><i class="bi bi-circle"></i>Service Buy History</a>
                            </li>
                            
                        </ul>
                    </li>

                    <li>
                        <a href="<?php echo e(route('support')); ?>">
                            <div class="parent-icon"><i class="bi bi-question-lg"></i></div>
                            <div class="menu-title">Support</div>
                        </a>
                    </li>

                    <li>
                        <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                            <div class="parent-icon"><i class="bi bi-lock-fill"></i></div>
                            <div class="menu-title">Logout</div>
                        </a>

                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                            <?php echo csrf_field(); ?>
                        </form>

                    </li>
                    <br>
                    <li>
                        <?php if(isset($ads->ads_1)): ?>
                        <a href="<?php echo e($ads->ads_link_1); ?>" target="_blank"><embed src="<?php echo e(asset('/uploads/ads_1/'.$ads->ads_1)); ?>" height="150"></a>
                        <h6 style="color: white; text-align: center;" ><?php echo e($ads->ads_text_1); ?></h6>
                        <?php endif; ?>

                    </li>

                    <li>
                        <?php if(isset($ads->ads_link_2)): ?>
                        <a href="<?php echo e($ads->ads_link_2); ?>" target="_blank"><embed src="<?php echo e(asset('/uploads/ads_2/'.$ads->ads_2)); ?>" height="150"></a>
                        <h6 style="color: white; text-align: center;"><?php echo e($ads->ads_text_2); ?></h6>
                        <?php endif; ?>
                    </li>
                </ul>
                <!--end navigation-->
            </aside>
            <!--end sidebar -->

            <!--start content-->
            <main class="page-content">
                
                <?php echo $__env->yieldContent('content'); ?>

            </main>
            <!--end page main-->

            <!--start overlay-->
            <div class="overlay nav-toggle-icon"></div>
            <!--end overlay-->

            <!--Start Back To Top Button-->
            <a href="javaScript:;" class="back-to-top"><i class="bx bxs-up-arrow-alt"></i></a>
            <!--End Back To Top Button-->
        </div>
        <!--end wrapper-->

        <!-- Bootstrap bundle JS -->
        <script src="<?php echo e(asset('admin')); ?>/assets/js/bootstrap.bundle.min.js"></script>
        <!--plugins-->
        <script src="<?php echo e(asset('admin')); ?>/assets/js/jquery.min.js"></script>
        <script src="<?php echo e(asset('admin')); ?>/assets/plugins/simplebar/js/simplebar.min.js"></script>
        <script src="<?php echo e(asset('admin')); ?>/assets/plugins/metismenu/js/metisMenu.min.js"></script>
        <script src="<?php echo e(asset('admin')); ?>/assets/plugins/perfect-scrollbar/js/perfect-scrollbar.js"></script>
        <script src="<?php echo e(asset('admin')); ?>/assets/js/pace.min.js"></script>
        <script src="<?php echo e(asset('admin')); ?>/assets/plugins/chartjs/js/Chart.min.js"></script>
        <script src="<?php echo e(asset('admin')); ?>/assets/plugins/chartjs/js/Chart.extension.js"></script>
        <script src="<?php echo e(asset('admin')); ?>/assets/plugins/apexcharts-bundle/js/apexcharts.min.js"></script>
        <!-- Vector map JavaScript -->
        <script src="<?php echo e(asset('admin')); ?>/assets/plugins/vectormap/jquery-jvectormap-2.0.2.min.js"></script>
        <script src="<?php echo e(asset('admin')); ?>/assets/plugins/vectormap/jquery-jvectormap-world-mill-en.js"></script>
        <script src="<?php echo e(asset('admin')); ?>/assets/plugins/select2/js/select2.min.js"></script>
        <script src="<?php echo e(asset('admin')); ?>/assets/js/form-select2.js"></script>
        <!--app-->
        <script src="<?php echo e(asset('admin')); ?>/assets/js/app.js"></script>
        <script src="<?php echo e(asset('admin')); ?>/assets/js/index.js"></script>
        <script>
            new PerfectScrollbar(".review-list");
            new PerfectScrollbar(".chat-talk");
        </script>

        <script src="<?php echo e(asset('admin')); ?>/assets/plugins/datatable/js/jquery.dataTables.min.js"></script>
        <script src="<?php echo e(asset('admin')); ?>/assets/plugins/datatable/js/dataTables.bootstrap5.min.js"></script>
        <script src="<?php echo e(asset('admin')); ?>/assets/js/table-datatable.js"></script>
    

        <!-- Toaster -->
        <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>

        <script>
            <?php if(Session::has('message')): ?>
                toastr.options =
                {
                    "closeButton" : true,
                    "progressBar" : true
                }
            toastr.success("<?php echo e(session('message')); ?>");
            <?php endif; ?>
                <?php if(Session::has('error')): ?>
                toastr.options =
                {
                    "closeButton" : true,
                    "progressBar" : true
                }
            toastr.error("<?php echo e(session('error')); ?>");
            <?php endif; ?>
                <?php if(Session::has('info')): ?>
                toastr.options =
                {
                    "closeButton" : true,
                    "progressBar" : true
                }
            toastr.info("<?php echo e(session('info')); ?>");
            <?php endif; ?>
                <?php if(Session::has('warning')): ?>
                toastr.options =
                {
                    "closeButton" : true,
                    "progressBar" : true
                }
            toastr.warning("<?php echo e(session('warning')); ?>");
            <?php endif; ?>
        </script>



     <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.0/sweetalert.min.js"></script>
<script type="text/javascript">
 
     $('.show_confirm').click(function(event) {
          var form =  $(this).closest("form");
          var name = $(this).data("name");
          event.preventDefault();
          swal({
              title: `Are you sure you want to delete this record?`,
              text: "If you delete this, it will be gone forever.",
              icon: "warning",
              buttons: true,
              dangerMode: true,
          })
          .then((willDelete) => {
            if (willDelete) {
              form.submit();
            }
          });
      });
  
</script>

    <script type="text/javascript">window.$crisp=[];window.CRISP_WEBSITE_ID="3e418e13-cfdd-4b14-a364-75429461209e";(function(){d=document;s=d.createElement("script");s.src="https://client.crisp.chat/l.js";s.async=1;d.getElementsByTagName("head")[0].appendChild(s);})();</script>

    </body>
</html>
<?php /**PATH D:\p project\ads\ads-agency\resources\views/user/master.blade.php ENDPATH**/ ?>