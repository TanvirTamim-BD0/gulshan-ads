<style>
table, th, td {
  border: 1px solid;
}

table {
  width: 100%;
}
</style>

<div class="card">
					<div class="card-body">
						<div class="table-responsive">
							<h3>Balance TopUp History</h3>

							<h5>Name : <?php echo e($userData->name); ?></h5>
							<h5>Email : <?php echo e($userData->email); ?></h5><br>
							<table style="width:100%">
								<thead>
									<tr>
										<th>SL</th>
										<th>Date</th>
										<th>Old Balance</th>
										<th>Update Balance</th>
										<th>Recharge Amount</th>
										<!-- <th>BDT</th> -->
									</tr>


									<?php $__currentLoopData = $balanceData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $balanace): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php if(isset($balanace)): ?>
									<tr>
										<td style="text-align: center;"><?php echo e($loop->iteration); ?></td>


										<td style="text-align: center;"><?php echo e($balanace->confirmed_date); ?></td>

										<td style="text-align: center;"><?php echo e($balanace->userData->balance - $balanace->usd); ?></td>

										<td style="text-align: center;"><?php echo e($balanace->userData->balance); ?></td>

										<td style="text-align: center;"><?php echo e($balanace->usd); ?></td>
										<!-- <td style="text-align: center;"><?php echo e($balanace->bdt); ?></td> -->
									</tr>
									<?php endif; ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

									<tr>
										<td></td>
										<td></td>
										<td></td>
										<td style="text-align: center;"><b>Total : </b></td>
										<td style="text-align: center;"><b><?php echo e($totalUsdBalanace); ?></b></td>
										<!-- <td style="text-align: center;"><b><?php echo e($totalBdtBalanace); ?></b></td> -->
									</tr>
									
								</tbody>
								
							</table>
						</div>
					</div>
				</div><?php /**PATH E:\p project\ads\ads-agency\resources\views/admin/balanaceTopUpReport/pdf.blade.php ENDPATH**/ ?>