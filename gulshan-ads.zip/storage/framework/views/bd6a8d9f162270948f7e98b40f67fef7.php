<?php $__env->startSection('content'); ?>

<h1>Create Ad Account</h1>

        <form action="<?php echo e(route('ad-account-create-submit',$adAccount->id)); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="card rounded-4 p-5">
                <div class="card-body">
                    <div class="row row-cols-1 row-cols-lg-1 row-cols-xl-1">  

                        <div class="col">
                            <div class="mb-3">
                            <label class="form-label">User</label>
										<select class="single-select" name="user_id" required>
											<option selected disabled>Select User</option>
											<?php $__currentLoopData = $userData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										  	<?php if(isset($user)): ?>
											<option value="<?php echo e($user->id); ?>" <?php echo e($user->id == $adAccount->user_id ? 'selected' : ''); ?> ><?php echo e($user->name); ?> (<?php echo e($user->userID); ?>) </option>
											<?php endif; ?>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>						
										</select>
                            </div>
                        </div>

                        <div class="col">
                            <div class="mb-3">
                                <label class="form-label">Ad Account Number</label>
                                <input type="text" class="form-control" value="" name="ad_account_number" required>
                            </div>
                        </div>

                    	<div class="col">
                            <div class="mb-3">
                                <label class="form-label">Ad Account Name</label>
                                <input type="text" class="form-control" value="" name="ad_name" required>
                                <?php $__errorArgs = ['ad_account_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class=text-danger><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="col">
                            <div class="mb-3">
                                <label class="form-label">Facebook Page URL 1</label>
                                <input type="text" class="form-control" name="facebook_page_url_1" value="<?php echo e($adAccount->facebook_page_url_1); ?>" required>
                            </div>
                        </div>
                        <div class="col">
                            <div class="mb-3">
                                <label class="form-label">Facebook Page URL 2 </label>
                                <input type="text" class="form-control" value="<?php echo e($adAccount->facebook_page_url_2); ?>" name="facebook_page_url_2">
                            </div>
                        </div>
                        <div class="col">
                            <div class="mb-3">
                                <label class="form-label">Facebook Page URL 3 </label>
                                <input type="text" class="form-control" value="<?php echo e($adAccount->facebook_page_url_3); ?>" name="facebook_page_url_3">
                            </div>
                        </div>
                        <div class="col">
                            <div class="mb-3">
                                <label class="form-label">Facebook Page URL 4 </label>
                                <input type="text" class="form-control" value="<?php echo e($adAccount->facebook_page_url_4); ?>" name="facebook_page_url_4">
                            </div>
                        </div>
                        <div class="col">
                            <div class="mb-2">
                                <label class="form-label">Facebook Page URL 5 </label>
                                <input type="text" class="form-control" value="<?php echo e($adAccount->facebook_page_url_5); ?>" name="facebook_page_url_5">
                            </div>
                        </div>

                        <div class="col">
                            <div class="mb-3">
                                <label class="form-label">Website or Destination URL</label>
                                <input type="text" class="form-control" value="<?php echo e($adAccount->website_url); ?>" name="website_url">
                            </div>
                        </div>
                        <div class="col">
                            <div class="mb-3">
                                <label class="form-label">Business Manager ID</label>
                                <input type="text" class="form-control" value="<?php echo e($adAccount->business_manager_id); ?>" name="business_manager_id" required>
                            </div>
                        </div>

                        <div class="col mt-4">
                            <button class="btn btn-primary px-4 ">Update</button>
                        </div>

                    
                    </div>
                </div>
            </div>
            
            
        </form>
   <?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\p project\ads\ads-agency\resources\views/admin/adAccount/createAdAccount.blade.php ENDPATH**/ ?>