<?php $__env->startSection('content'); ?>
	
	<h1>Ad Account Rename</h1>

        <form action="<?php echo e(route('ad-account-rename-request-submit')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="card rounded-4 p-5">
                <div class="card-body">
                    <div class="row row-cols-1 row-cols-lg-1 row-cols-xl-1">

                    	<div class="col">
                    		<div class="mb-3">
									<label class="form-label">Ad Account</label>
										<select class="single-select" name="ad_account_id" id="ad_account_id" required>
											<option selected disabled>Select Ad Account</option>
											<?php $__currentLoopData = $accountData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										 	 <?php if(isset($account)): ?>
											<option value="<?php echo e($account->id); ?>"><?php echo e($account->ad_name); ?> (<?php echo e($account->ad_account_number); ?>)</option>
											<?php endif; ?>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>				
										</select>
								  </div>
						</div>


                        <!-- <div class="col">
                            <div class="mb-3">
                                <label class="form-label">Old Name</label>
                                <input type="text" class="form-control" name="old_name" required>
                            </div>
                        </div> -->

                        <div class="col">
                            <div class="mb-3">
                                <label class="form-label">New Name </label>
                                <input type="text" class="form-control" name="new_name">
                            </div>
                        </div>
                        

                        <div class="col">
                            <button class="btn btn-primary px-4 float-end">Submit</button>
                        </div>
                    
                    </div>
                </div>
            </div>
            
        </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\p project\ads\ads-agency\resources\views/user/adAccount/renameRequest.blade.php ENDPATH**/ ?>