<?php $__env->startSection('content'); ?>
	 <h6 class="mb-0 text-uppercase">Edit TopUp Request Balance</h6>
	<hr/>
	<div class="row">
		<div class="col-xl-8 mx-auto">		
			<div class="card">
              <div class="card-body">
                <div class="border p-3 rounded">
                <h6 class="mb-0 text-uppercase">Edit TopUp Request Balance</h6>
                <hr/>

                <form class="row g-3" action="<?php echo e(route('update-balance',$balanceData->id)); ?>" method="post">
                <?php echo csrf_field(); ?>

                  <div class="col-12">
                    <label class="form-label">Amount</label>
                    <input type="number" class="form-control" name="usd" value="<?php echo e($balanceData->usd); ?>" required>
                  </div>

                  <div class="col-12">
                    <div class="">
                      <button type="submit" class="btn btn-primary">Update</button>
                    </div>
                  </div>

                </form>

              </div>
              </div>
            </div>

		</div>
	</div>
	<!--end row-->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\p project\ads\ads-agency\resources\views/admin/balance/edit.blade.php ENDPATH**/ ?>