<?php $__env->startSection('content'); ?>
    <h6 class="mb-0 text-uppercase">Ad Account Disabled History</h6>
				<hr/>

				<div class="card">
					<div class="card-body">
						<div class="table-responsive">
							<table id="example" class="table table-striped table-bordered" style="width:100%">
								<thead>
									<tr>
										<th>SL</th>
										<th>Ad Account</th>
										<th>Date</th>
										<th class="text-center">Status</th>
									</tr>
								</thead>
								<tbody>

									<?php $__currentLoopData = $appealData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adAccount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php if(isset($adAccount)): ?>
									<tr>
										<td><?php echo e($loop->iteration); ?></td>
										<td><?php echo e($adAccount->adAccountData->ad_name); ?> (<?php echo e($adAccount->adAccountData->ad_account_number); ?>)</td>
										<td><?php echo e($adAccount->created_at); ?></td>
									
										
										<?php if($adAccount->status == 'Reject'): ?>
										<td class="text-center"><span class="badge bg-danger text-white" style="padding: 10px;"> Rejected </span></td>
										<?php else: ?>
										<td class="text-center"><span class="badge bg-warning text-white" style="padding: 10px;"> Under Review </span></td>
										<?php endif; ?>
										
									</tr>

									<?php endif; ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

								</tbody>
								
							</table>
						</div>
					</div>
				</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\p project\ads\ads-agency\resources\views/user/history/appealHistory.blade.php ENDPATH**/ ?>