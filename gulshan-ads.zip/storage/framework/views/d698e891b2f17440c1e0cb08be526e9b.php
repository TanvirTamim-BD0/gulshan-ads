<?php $__env->startSection('content'); ?>
    <h6 class="mb-0 text-uppercase">Campaign Request</h6>
				<hr/>
				<div class="card">
					<div class="card-body">
						<div class="table-responsive">
							<table id="example" class="table table-striped table-bordered" style="width:100%">
								<thead>
									<tr>
										<th>SL</th>
										<th>User</th>
										<th>Post</th>
										<th>Details</th>
										<th>Audience</th>
										<th>Placement</th>
										<th>Date</th>
										<th class="text-center">Status</th>
										<th>Action</th>
									</tr>
								</thead>
								<tbody>
									<?php $__currentLoopData = $campaignData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $campaign): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php if(isset($campaign)): ?>
									<tr>
										<td><?php echo e($loop->iteration); ?></td>
										<td><?php echo e($campaign->userData->name); ?> (<?php echo e($campaign->userData->userID); ?>)</td>
										<td>
											Post Title/Link : <?php echo e($campaign->post_link); ?> <br>

											<?php if($campaign->post_image): ?>
											Post Image : <img src="<?php echo e(asset('/uploads/post_image/'.$campaign->post_image)); ?>" width="65" height="55" alt="">
											<?php endif; ?>
										</td>

										<td>
											Type : <?php echo e($campaign->campaign_type); ?> <br>
											Budget : <?php echo e($campaign->budget); ?> <br>
											Days : <?php echo e($campaign->days); ?> <br>
											Editor Access  : <?php echo e($campaign->editor_access); ?> <br>
										</td>

										<td>
											Location : <?php echo e($campaign->audienceData->area); ?> , <?php echo e($campaign->audienceData->district); ?> , <?php echo e($campaign->audienceData->country); ?> <br>
											Detailed Targeting : <?php echo e($campaign->detailed_targeting_type); ?> , <?php echo e($campaign->detailed_targeting_name); ?> <br>
											Detailed Targeting Child : 
											<a href="#" style="text-decoration: underline;"  data-bs-toggle="modal"
	                                        data-bs-target="#childView<?php echo e($campaign->id); ?>" class="text-primary" data-bs-toggle="tooltip" data-bs-placement="bottom" title="View"><i class="bi bi-eye"></i> View</a> 
											
											 <br>
											Gender : <?php echo e($campaign->gender); ?> <br>
											Age Start-End : <?php echo e($campaign->age_start); ?> - <?php echo e($campaign->age_end); ?> <br>
										</td>

										<td>
											Facebook : <?php echo e($campaign->facebook); ?> <br>
											Instagram : <?php echo e($campaign->instagram); ?> <br>
											Messenger : <?php echo e($campaign->messenger); ?> <br>
											Whatsapp : <?php echo e($campaign->whatsapp); ?> <br>
										</td>

										<td><?php echo e($campaign->created_at); ?></td>


										<?php if($campaign->status == 'Confirmed'): ?>
										<td class="text-center"><span class="badge bg-success text-white" style="padding: 10px;"> Confirmed </span></td>
										<?php elseif($campaign->status == 'Reject'): ?>
										<td class="text-center"><span class="badge bg-danger text-white" style="padding: 10px;"> Reject </span></td>
										<?php else: ?>
										<td class="text-center"><span class="badge bg-warning text-white" style="padding: 10px;"> Pending </span></td>
										<?php endif; ?>


										<td>
				                            <?php if($campaign->status == 'Confirmed'): ?>
				                        	<?php else: ?>
				                            <a href="javascript:;" data-bs-toggle="modal"
	                                        data-bs-target="#confirmedData<?php echo e($campaign->id); ?>"  class="text-success" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Reject"><i class="bi bi-check-circle"></i> Confirmed</a><br>
				                            <?php endif; ?>
 
				                            <?php if($campaign->status == 'Reject'): ?>
				                            <?php else: ?>
				                            <a href="javascript:;" data-bs-toggle="modal"
	                                        data-bs-target="#rejectedData<?php echo e($campaign->id); ?>"  class="text-danger" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Reject"><i class="bi bi-file-earmark-x"></i> Reject</a><br>
	                                        <?php endif; ?>
				                         </td>
									
									</tr>

									<!-- child show -->
									<div class="modal fade" id="childView<?php echo e($campaign->id); ?>" tabindex="-1"
                                        aria-labelledby="usd_detailsLabel" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="usd_detailsLabel">Detailed Targeting Child</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                        aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">

                                                	<?php
			                                            $getChiledData = App\Models\Campaign::getChiledData($campaign->id);      
			                                        ?>

                                                    <?php $__currentLoopData = $getChiledData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chiledData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<span class="badge mt-2" style="background-color: #0d6efd; color: white; padding: 4px 8px; text-align: center; border-radius: 5px;">
													<?php echo e($chiledData->name); ?>

												    </span>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary"
                                                        data-bs-dismiss="modal">Close</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>


									<!-- Confirmed Text -->
                                    <div class="modal fade" id="confirmedData<?php echo e($campaign->id); ?>" tabindex="-1"
                                        aria-labelledby="usd_detailsLabel" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <form action="<?php echo e(route('campaign-request-confirmed',$campaign->id)); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="service_buy_id" value="<?php echo e($campaign->id); ?>">
                                               	<div class="modal-header">
                                                    <h5 class="modal-title" id="usd_detailsLabel">Text</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                        aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="row">
                                                        <div class="col-md-12 col-lg-12">
                                                            	<textarea class="form-control" cols="20" rows="5" name="confirmed_text">
                                                            		
                                                            	</textarea>
                                                        </div>
                                                        
                                                    </div>
                                                </div>

                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary"
                                                        data-bs-dismiss="modal">Close</button>
                                                     <button type="submit" class="btn btn-primary"
                                                        data-bs-dismiss="modal">Submit</button>
                                                </div>

                                                </form>
                                            </div>
                                        </div>
                                    </div>

									<!-- Rejected Text -->
                                    <div class="modal fade" id="rejectedData<?php echo e($campaign->id); ?>" tabindex="-1"
                                        aria-labelledby="usd_detailsLabel" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <form action="<?php echo e(route('campaign-request-reject',$campaign->id)); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="service_buy_id" value="<?php echo e($campaign->id); ?>">
                                               	<div class="modal-header">
                                                    <h5 class="modal-title" id="usd_detailsLabel">Rejected Text</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                        aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="row">
                                                        <div class="col-md-12 col-lg-12">
                                                            	<textarea class="form-control" cols="20" rows="5" name="rejected_text">
                                                            		
                                                            	</textarea>
                                                        </div>
                                                        
                                                    </div>
                                                </div>

                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary"
                                                        data-bs-dismiss="modal">Close</button>
                                                     <button type="submit" class="btn btn-primary"
                                                        data-bs-dismiss="modal">Submit</button>
                                                </div>

                                                </form>
                                            </div>
                                        </div>
                                    </div>


									<?php endif; ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									
								</tbody>
								
							</table>
						</div>
					</div>
				</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\p project\ads\ads-agency\resources\views/admin/campaign.blade.php ENDPATH**/ ?>