<?php $__env->startSection('content'); ?>
    <h6 class="mb-0 text-uppercase">Payment Method List</h6>
				<hr/>

				<div align="right">
					<a href="<?php echo e(route('payment-method.create')); ?>" class="btn btn-primary">Add Payment Method</a>
				</div><br>

				<div class="card">
					<div class="card-body">
						<div class="table-responsive">
							<table id="example" class="table table-striped table-bordered" style="width:100%">
								<thead>
									<tr>
										<th>SL</th>
										<th>Payment Mathod</th>
										<th>Ac Number</th>
										<th>Action</th>
									</tr>
								</thead>
								<tbody>

									<?php $__currentLoopData = $paymentMethodData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paymentMethod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php if(isset($paymentMethod)): ?>
									<tr>
										<td><?php echo e($loop->iteration); ?></td>
										<td><?php echo e($paymentMethod->paymentMethodCategoryData->payment_method); ?></td>
										<td><?php echo e($paymentMethod->ac_number); ?></td>
										
										<td>
				                            <div class="table-actions  fs-6">
											  
											  <form method="POST" action="<?php echo e(route('payment-method.destroy', $paymentMethod->id)); ?>"
                                               >
                                              <?php echo csrf_field(); ?>
                                              <?php echo method_field('delete'); ?>
				                          
				                              <button type="submit" title="delete" id="show_confirm" class="bg-transparent border-0 text-danger" style="margin-left: -8px;"> <span><i class="bi bi-trash"></i> Delete</span>
                                           	  </button> <br>
				                              </form>

				                            </div>
				                         </td>

									</tr>
									<?php endif; ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

									
								</tbody>
								
							</table>
						</div>
					</div>
				</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\p project\ads\ads-agency\resources\views/admin/paymentMethod/index.blade.php ENDPATH**/ ?>