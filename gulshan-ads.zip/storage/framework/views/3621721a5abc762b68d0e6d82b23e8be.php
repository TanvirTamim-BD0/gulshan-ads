
<?php $__env->startSection('content'); ?>
    <h6 class="mb-0 text-uppercase">Ad Account Daily Spending</h6>
				<hr/>



				<div class="card">
					<div class="card-body">
						<div class="table-responsive">
							<table id="example" class="table table-striped table-bordered" style="width:100%">
								<thead>
									<tr>
										<th>SL</th>
										<th>Ad Account</th>
										<th>Daily Spending Limit BY meta</th>
										<th>Daily Spending User</th>
									</tr>
								</thead>
								<tbody>

									<?php $__currentLoopData = $adAccountData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adAccount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php if(isset($adAccount)): ?>
									<tr>
										<td><?php echo e($loop->iteration); ?></td>

										<td>
											<?php echo e($adAccount->ad_name); ?> (<?php echo e($adAccount->ad_account_number); ?>) <br>
										</td>
										
										<td>
											<?php echo e($adAccount->daily_limit); ?> <br>
											<a href="#" style="text-decoration: underline;"  data-bs-toggle="modal"
	                                        data-bs-target="#daily_limit<?php echo e($adAccount->id); ?>" class="text-primary" data-bs-toggle="tooltip" data-bs-placement="bottom" title="View"><i class="bi bi-pencil-fill"></i> Edit</a> 
										</td>
										
										
										<td>
											<?php echo e($adAccount->daily_spending_user); ?> <br>
											<a href="#" style="text-decoration: underline;"  data-bs-toggle="modal"
	                                        data-bs-target="#daily_spending_user<?php echo e($adAccount->id); ?>" class="text-primary" data-bs-toggle="tooltip" data-bs-placement="bottom" title="View"><i class="bi bi-pencil-fill"></i> Edit</a> 
										</td>
										
									</tr>

									<!-- daily_limit Modal -->
									<div class="modal fade" id="daily_limit<?php echo e($adAccount->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
									  <div class="modal-dialog">
									    <div class="modal-content">
									      <div class="modal-header">
									        <h5 class="modal-title" id="exampleModalLabel">Update Data</h5>
									        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
									      </div>

									      <form action="<?php echo e(route('update-account-data',$adAccount->id)); ?>" method="post">
            							  <?php echo csrf_field(); ?>
									      <div class="modal-body">
					                        <div class="col">
					                            <div class="mb-3">
					                                <label class="form-label">Daily Spending Limit BY meta</label>
					                                <input type="text" class="form-control" value="<?php echo e($adAccount->daily_limit); ?>" name="daily_limit" required>
					                            </div>
					                        </div>
									      </div>
									      <div class="modal-footer">
									        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
									        <button type="submit" class="btn btn-primary">Save changes</button>
									      </div>
									      </form>
									    </div>
									  </div>
									</div>

									<!-- daily_spending_user Modal -->
									<div class="modal fade" id="daily_spending_user<?php echo e($adAccount->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
									  <div class="modal-dialog">
									    <div class="modal-content">
									      <div class="modal-header">
									        <h5 class="modal-title" id="exampleModalLabel">Update Data</h5>
									        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
									      </div>

									      <form action="<?php echo e(route('update-account-data',$adAccount->id)); ?>" method="post">
            							  <?php echo csrf_field(); ?>
									      <div class="modal-body">

					                        <div class="col">
					                            <div class="mb-3">
					                                <label class="form-label">Daily Spending User</label>
					                                <input type="text" class="form-control" value="<?php echo e($adAccount->daily_spending_user); ?>" name="daily_spending_user">
					                            </div>
					                        </div>
									      </div>
									      <div class="modal-footer">
									        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
									        <button type="submit" class="btn btn-primary">Save changes</button>
									      </div>
									      </form>
									    </div>
									  </div>
									</div>


                                    <?php endif; ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

								</tbody>
								
							</table>
						</div>
					</div>
				</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\p project\ads\ads-agency\resources\views/admin/spending.blade.php ENDPATH**/ ?>