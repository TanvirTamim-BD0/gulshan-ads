
<?php $__env->startSection('content'); ?>
	 <h6 class="mb-0 text-uppercase">Editor Access</h6>
	<hr/>
	<div class="row">
		<div class="col-xl-10 mx-auto">		
			<div class="card">
              <div class="card-body">
                <div class="border p-3 rounded">
                <h6 class="mb-0 text-uppercase">Editor Access</h6>
                <hr/>

                <form class="row g-3" action="<?php echo e(route('editor-access.update',$access->id)); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('put'); ?>


                  <div class="col-md-12">
                          <label class="form-label">Editor 1</label>
                          <input type="text" class="form-control" value="<?php echo e($access->editor_1); ?>" name="editor_1">
                  </div>

                  <div class="col-md-12">
                          <label class="form-label">Editor 2</label>
                          <input type="text" class="form-control" value="<?php echo e($access->editor_2); ?>" name="editor_2">
                  </div>

                  <div class="col-md-12">
                          <label class="form-label">Note</label>
                          <textarea class="form-control" name="note" ><?php echo e($access->note); ?></textarea>
                  </div>
            
                  <div class="col-12">
                    <div class="">
                      <button type="submit" class="btn btn-primary">Update</button>
                    </div>
                  </div>

                </form>

              </div>
              </div>
            </div>

		</div>
	</div>
	<!--end row-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\p project\ads\ads-agency\resources\views/admin/editorAccess/index.blade.php ENDPATH**/ ?>