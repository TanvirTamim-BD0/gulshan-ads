<?php $__env->startSection('content'); ?>
    <h6 class="mb-0 text-uppercase">Ad Account Request</h6>
				<hr/>

				<div align="right">
					<a href="<?php echo e(route('create-ad-account')); ?>" class="btn btn-primary">Create Ad Account</a>
				</div><br>

				<div class="card">
					<div class="card-body">
						<div class="table-responsive">

							<div align="right">
								<a href="<?php echo e(route('ad-account-request-status-filter','Created')); ?>" class="btn btn-success">Created</a>

								<a href="<?php echo e(route('ad-account-request-status-filter','Reject')); ?>" class="btn btn-danger">Reject</a>

								<a href="<?php echo e(route('ad-account-request-status-filter','Pending')); ?>" class="btn btn-warning">Pending</a>
							</div><br>
							
							<table id="example" class="table table-striped table-bordered" style="width:100%">
								<thead>
									<tr>
										<th>SL</th>
										<th>User</th>
										<th>Account Name</th>
										<th>Facebook Page</th>
										<th>Website</th>
										<th>Business Manager Id</th>
										<th>Time Zone</th>
										<th>Request Time</th>
										<th class="text-center">Status</th>
										<th>Action</th>
									</tr>
								</thead>
								<tbody>
									
									<?php $__currentLoopData = $adAccountRequestData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adAccount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php if(isset($adAccount)): ?>
									<tr>
										<td><?php echo e($loop->iteration); ?></td>
										<td><?php echo e($adAccount->userData->name); ?> (<?php echo e($adAccount->userData->userID); ?>)</td>
										<td><?php echo e($adAccount->account_name); ?></td>
										<td>
											<a href="#" data-bs-toggle="modal"
	                                        data-bs-target="#details<?php echo e($adAccount->id); ?>" class="text-primary" data-bs-toggle="tooltip" data-bs-placement="bottom" title="View"><i class="bi bi-eye"></i> View</a>
										</td>
										<td><?php echo e($adAccount->website_url); ?></td>
										<td><?php echo e($adAccount->business_manager_id); ?></td>
										<td><?php echo e($adAccount->time_zone_name); ?></td>
										<td><?php echo e($adAccount->created_at); ?></td>

										<?php if($adAccount->status == 'Created'): ?>
										<td class="text-center"><span class="badge bg-success text-white" style="padding: 10px;"> Created </span></td>
										<?php elseif($adAccount->status == 'Reject'): ?>
										<td class="text-center"><span class="badge bg-danger text-white" style="padding: 10px;"> Reject </span></td>
										<?php else: ?>
										<td class="text-center"><span class="badge bg-warning text-white" style="padding: 10px;"> Pending </span></td>
										<?php endif; ?>
										
										<td>
				                            <div class="table-actions  fs-6">
				                            <a href="<?php echo e(route('ad-account-create',$adAccount->id)); ?>" class="text-primary" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Create Account"><i class="bi bi-pencil-square"></i> Create Account </a><br>

				                            <?php if($adAccount->status == 'Reject'): ?>
				                            <?php else: ?>
				                            <a href="javascript:;" data-bs-toggle="modal"
	                                        data-bs-target="#rejectedData<?php echo e($adAccount->id); ?>"  class="text-danger" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Reject"><i class="bi bi-file-earmark-x"></i> Reject</a>
	                                        <?php endif; ?>

				                            </div>
				                            

				                         </td>
									</tr>

									<!-- details show -->
									<div class="modal fade" id="details<?php echo e($adAccount->id); ?>" tabindex="-1"
                                        aria-labelledby="usd_detailsLabel" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="usd_detailsLabel">Facebook Page</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                        aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="row">
                                                        <div class="col-md-12 col-lg-12">
                                                            <p><strong>Facebook page 1:</strong> <?php echo e($adAccount->facebook_page_url_1); ?> </p>
                                                            <p><strong>Facebook page 2:</strong>  <?php echo e($adAccount->facebook_page_url_2); ?> </p>
                                                            <p><strong>Facebook page 3:</strong>  <?php echo e($adAccount->facebook_page_url_3); ?> </p>
                                                            <p><strong>Facebook page 4:</strong> <?php echo e($adAccount->facebook_page_url_4); ?> </p>
                                                            <p><strong>Facebook page 5:</strong>  <?php echo e($adAccount->facebook_page_url_5); ?> </p>

                                                        </div>
                                                        
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary"
                                                        data-bs-dismiss="modal">Close</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>


                                    <!-- Rejected Text -->
                                    <div class="modal fade" id="rejectedData<?php echo e($adAccount->id); ?>" tabindex="-1"
                                        aria-labelledby="usd_detailsLabel" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <form action="<?php echo e(route('ad-account-request-reject')); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="ad_account_request_id" value="<?php echo e($adAccount->id); ?>">
                                               	<div class="modal-header">
                                                    <h5 class="modal-title" id="usd_detailsLabel">Rejected Text</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                        aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="row">
                                                        <div class="col-md-12 col-lg-12">
                                                            
                                                            	<textarea class="form-control" cols="20" rows="5" name="rejected_text">
                                                            		
                                                            	</textarea>
                                                        </div>
                                                        
                                                    </div>
                                                </div>

                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary"
                                                        data-bs-dismiss="modal">Close</button>
                                                     <button type="submit" class="btn btn-primary"
                                                        data-bs-dismiss="modal">Submit</button>
                                                </div>

                                                </form>
                                            </div>
                                        </div>
                                    </div>

                                    <?php endif; ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

									
								</tbody>
								
							</table>
						</div>
					</div>
				</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\p project\ads\ads-agency\resources\views/admin/adAccount/adAccountRequest.blade.php ENDPATH**/ ?>