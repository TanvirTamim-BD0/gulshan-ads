<?php $__env->startSection('content'); ?>
	
	<div class="card bg-transparent shadow-none">
                    <div class="card-body">
                        <h6 class="mb-0 text-uppercase">Guides</h6>
                        <div class="my-3 border-top"></div>
                        <div class="card-group">
                            <div class="row">

                                <?php $__currentLoopData = $guidesData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($data): ?>
                                <div class="col-md-4" style="width: 400px;">
                                    <div class="card border-end">
                                        <img src="<?php echo e(asset('/uploads/guides_image/'.$data->image)); ?>" width="200"  class="card-img-top" alt="..." style="height: 250px;" >
                                        <div class="card-body">
                                            <h5 class="card-title"><?php echo e($data->title); ?></h5>
                                           
                                            <a href="<?php echo e(route('guide-details',$data->id)); ?>" class="btn btn-primary">Read More</a>
                                        </div>
                                    </div>
                                </div>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                            </div>                            
                        </div>
                    </div>
                </div>
                

<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\p project\ads\ads-agency\resources\views/user/guides.blade.php ENDPATH**/ ?>