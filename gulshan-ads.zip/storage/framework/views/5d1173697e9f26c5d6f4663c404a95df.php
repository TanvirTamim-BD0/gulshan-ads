<?php $__env->startSection('content'); ?>
	 <h6 class="mb-0 text-uppercase">Update Payment Method Category</h6>
	<hr/>
	<div class="row">
		<div class="col-xl-8 mx-auto">		
			<div class="card">
              <div class="card-body">
                <div class="border p-3 rounded">
                <h6 class="mb-0 text-uppercase">Update Payment Method Category</h6>
                <hr/>

                <form class="row g-3" action="<?php echo e(route('payment-method-category.update',$paymentMethodCategoryData->id)); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('put'); ?>

                <div class="col-12">
                    <label class="form-label">Payment Type</label>
                    <select class="single-select" name="payment_type" required>
                      <option selected disabled>Select Payment Type</option>
                      <option value="Bank" <?php echo e($paymentMethodCategoryData->payment_type == 'Bank' ? 'selected' : ''); ?>>Bank</option>  
                      <option value="Mobile Banking" <?php echo e($paymentMethodCategoryData->payment_type == 'Mobile Banking' ? 'selected' : ''); ?>>Mobile Banking</option>         
                    </select>
                  </div>

                  <div class="col-12">
                    <label class="form-label">Payment Method</label>
                    <input type="text" name="payment_method" class="form-control" value="<?php echo e($paymentMethodCategoryData->payment_method); ?>">
                  </div>

                  <div class="col-md-12">    
                        <label class="form-label">Icon</label><br>
                        <input class="form-control" type="file" name="icon" /><br>
                        <?php if(isset($paymentMethodCategoryData->icon)): ?>
                            <img src="<?php echo e(asset('/uploads/payment_method_icon/'.$paymentMethodCategoryData->icon)); ?>" height="50" width="100">
                        <?php endif; ?>
                      </div>

                  <div class="col-12">
                    <div class="">
                      <button type="submit" class="btn btn-primary">Update Payment Method</button>
                    </div>
                  </div>

                </form>

              </div>
              </div>
            </div>

		</div>
	</div>
	<!--end row-->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\p project\ads\ads-agency\resources\views/admin/paymentMethodCategory/edit.blade.php ENDPATH**/ ?>