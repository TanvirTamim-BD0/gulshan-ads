<?php $__env->startSection('content'); ?>
    <h6 class="mb-0 text-uppercase">Balance Report</h6>
				<hr/>

				<form class="row g-3" action="<?php echo e(route('pdf-account-balance-data')); ?>" method="post">
                <?php echo csrf_field(); ?>

                <input type="hidden" name="user_id" value="<?php echo e($userID); ?>">

				<div style="margin-right: 20;">
					<button type="submit" class="btn btn-danger">PDF</button>
				</div>

				</form>
				<br>

				<div class="card">
					<div class="card-body">
						<div class="table-responsive">
							<table id="" class="table table-striped table-bordered" style="width:100%">
								<thead>
									<tr>
										<th>SL</th>
										<th>Payment Method</th>
										<th>Date</th>
										<th>Old Balance</th>
										<th>Update Balance</th>
										<th>Recharge Amount</th>
										<!-- <th>BDT</th> -->
									</tr>
								</thead>
								<tbody>

									<h5>Name : <?php echo e($userData->name); ?></h5>
									<h5>Email : <?php echo e($userData->email); ?></h5><br>

									<?php $__currentLoopData = $balanceData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $balanace): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php if(isset($balanace)): ?>
									<tr>
										<td><?php echo e($loop->iteration); ?></td>

										<?php if($balanace->manual_payment ==  null): ?>
										<td><?php echo e($balanace->paymentMethodData->paymentMethodCategoryData->payment_method); ?> (<?php echo e($balanace->paymentMethodData->ac_number); ?>) </td>
										<?php else: ?>
										<td><?php echo e($balanace->manual_payment); ?></td>
										<?php endif; ?>

										<td><?php echo e($balanace->confirmed_date); ?></td>

										<td><?php echo e($balanace->userData->balance - $balanace->usd); ?></td>

										<td><?php echo e($balanace->userData->balance); ?></td>

										<td><?php echo e($balanace->usd); ?></td>
										<!-- <td><?php echo e($balanace->bdt); ?></td> -->
									</tr>
									<?php endif; ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

									<tr>
										<td></td>
										<td></td>
										<td></td>
										<td></td>
										<td><b>Total : </b></td>
										<td><b><?php echo e($totalUsdBalanace); ?></b></td>
										<!-- <td><b><?php echo e($totalBdtBalanace); ?></b></td> -->
									</tr>
									
								</tbody>
								
							</table>
						</div>
					</div>
				</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\p project\ads\ads-agency\resources\views/admin/balanaceTopUpReport/index.blade.php ENDPATH**/ ?>