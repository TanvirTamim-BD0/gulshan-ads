<?php $__env->startSection('content'); ?>
    <h6 class="mb-0 text-uppercase">User List</h6>
				<hr/>

				<div align="right">
					<a href="<?php echo e(route('users.create')); ?>" class="btn btn-primary">Add User</a>
				</div><br>

				<div class="card">
					<div class="card-body">
						<div class="table-responsive">
							<table id="example" class="table table-striped table-bordered" style="width:100%">
								<thead>
									<tr>
										<th>SL</th>
										<th>ID</th>
										<th>Name</th>
										<th>Company Name</th>
										<th>Whatsapp Number</th>
										<th>Email</th>
										<th>Balance</th>
										<th>Action</th>
									</tr>
								</thead>
								<tbody>

									<?php $__currentLoopData = $userData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php if(isset($user)): ?>
									<tr>
										<td><?php echo e($loop->iteration); ?></td>
										<td><?php echo e($user->userID); ?></td>
										<td><?php echo e($user->name); ?></td>
										<td><?php echo e($user->company_name); ?></td>
										<td><?php echo e($user->whatsapp_number); ?></td>
										<td><?php echo e($user->email); ?></td>
										<td><?php echo e($user->balance); ?></td>
										<td>
				                            <div class="table-actions  fs-6">
											  
											  <form method="POST" action="<?php echo e(route('users.destroy', $user->id)); ?>"
                                               >
                                              <?php echo csrf_field(); ?>
                                              <?php echo method_field('delete'); ?>
				                          
				                              <button type="submit" title="delete" id="show_confirm" class="bg-transparent border-0 text-danger" style="margin-left: -8px;"> <span><i class="bi bi-trash"></i> Delete</span>
                                           	  </button> <br>
				                              </form>

				                              <a href="<?php echo e(route('users.edit',$user->id)); ?>" class="text-success" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit"><i class="bi bi-pencil-square"></i> Edit</a>

				                            </div>
				                         </td>

									</tr>
									<?php endif; ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


								</tbody>
								
							</table>
						</div>
					</div>
				</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\p project\ads\ads-agency\resources\views/admin/users/index.blade.php ENDPATH**/ ?>