<?php $__env->startSection('content'); ?>
    <h6 class="mb-0 text-uppercase">Services List</h6>
				<hr/>

				<div align="right">
					<a href="<?php echo e(route('service.create')); ?>" class="btn btn-primary">Add Service</a>
				</div><br>

				<div class="card">
					<div class="card-body">
						<div class="table-responsive">
							<table id="example" class="table table-striped table-bordered" style="width:100%">
								<thead>
									<tr>
										<th>SL</th>
										<th>Image</th>
										<th>Category</th>
										<th>Name</th>
										<th>Price</th>
										<th>Action</th>
									</tr>
								</thead>
								<tbody>

									<?php $__currentLoopData = $serviceData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php if(isset($service)): ?>
									<tr>
										<td><?php echo e($loop->iteration); ?></td>
										<td class="text-center"><img src="<?php echo e(asset('/uploads/service_image/'.$service->image)); ?>" width="65" height="55" alt=""></td>
										<td><?php echo e($service->serviceCategoryData->category_name); ?></td>
										<td><?php echo e($service->name); ?></td>
										<td><?php echo e($service->price); ?></td>
										<td>
				                            <div class="table-actions  fs-6">

				                              <a href="<?php echo e(route('service-view',$service->id)); ?>" class="text-primary" data-bs-toggle="tooltip" data-bs-placement="bottom" title="View"><i class="bi bi-eye"></i> View</a><br>

				                              <form method="POST" action="<?php echo e(route('service.destroy', $service->id)); ?>"
                                               >
                                              <?php echo csrf_field(); ?>
                                              <?php echo method_field('delete'); ?>
				                          
				                              <button type="submit" id="show_confirm" title="delete" class="bg-transparent border-0 text-danger" style="margin-left: -8px;"> <span><i class="bi bi-trash"></i> Delete</span>
                                           	  </button> <br>
				                              </form>

				                              <a href="<?php echo e(route('service.edit',$service->id)); ?>" class="text-success" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Edit"><i class="bi bi-pencil-square"></i> Edit</a>
				                            </div>
				                         </td>
									</tr>
									<?php endif; ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									
								</tbody>
								
							</table>
						</div>
					</div>
				</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\p project\ads\ads-agency\resources\views/admin/services/index.blade.php ENDPATH**/ ?>