<?php $__env->startSection('content'); ?>
    <h6 class="mb-0 text-uppercase">Service Buy Report</h6>
				<hr/>

				<div class="card">
					<div class="card-body">
						<div class="table-responsive">
							<table id="example" class="table table-striped table-bordered" style="width:100%">
								<thead>
									<tr>
										<th>Invoice No</th>
										<th>Service</th>
										<th>Amount</th>
										<th>Buying Date</th>
										<th>Confirmed Text</th>
										<th class="text-center">Status</th>
									</tr>
								</thead>
								<tbody>

									<?php $__currentLoopData = $buyServiceData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buyService): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php if(isset($buyService)): ?>
									<tr>
										<td><?php echo e($buyService->invoice_no); ?></td>
										<td><?php echo e($buyService->serviceData->name); ?></td>
										<td><?php echo e($buyService->serviceData->price); ?></td>
										<td><?php echo e($buyService->created_at->toDateString()); ?></td>
										<td><?php echo e($buyService->confirmed_text); ?></td>

										<td class="text-center">
										<?php if($buyService->status == 'Pending'): ?>
										<span class="badge bg-warning text-white" style="padding: 10px;"> Pending </span>
										<?php else: ?>
										<span class="badge bg-success text-white" style="padding: 10px;"> Paid </span>
										<?php endif; ?>
										
										</td>
									</tr>

								
									<?php endif; ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

									
									
									
								</tbody>
								
							</table>
						</div>
					</div>
				</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\p project\ads\ads-agency\resources\views/user/buyServiceInvoice.blade.php ENDPATH**/ ?>