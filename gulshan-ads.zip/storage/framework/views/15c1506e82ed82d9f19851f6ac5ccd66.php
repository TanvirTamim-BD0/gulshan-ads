<?php $__env->startSection('content'); ?>
        
    <div class="card">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <h5 class="mb-0">Balance TopUp Request</h5>
                        </div>
                        <div class="table-responsive mt-3">
                            <table id="" class="table align-middle mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th>SL</th>
                                        <th>Date</th>
                                        <th>User</th>
                                        <th>Method</th>
                                        <th>USD</th>
                                        <th>BDT</th>
                                        <th class="text-center">Status</th>
                                    </tr>
                                </thead>
                                <tbody>

                                  <?php $__currentLoopData = $balanceTopUpData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $balanceTopUp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <?php if(isset($balanceTopUp)): ?>
                                  <tr>
                                      <td><?php echo e($loop->iteration); ?></td>
                                      <td> <?php echo e($balanceTopUp->created_at->format('d M Y')); ?> </td>
                                      <td><?php echo e($balanceTopUp->userData->name); ?> (<?php echo e($balanceTopUp->userData->userID); ?>)</td>

                                      <?php if($balanceTopUp->manual_payment ==  null): ?>
                                      <td><?php echo e($balanceTopUp->paymentMethodData->paymentMethodCategoryData->payment_method); ?> (<?php echo e($balanceTopUp->paymentMethodData->ac_number); ?>) </td>
                                      <?php else: ?>
                                        <td><?php echo e($balanceTopUp->manual_payment); ?></td>
                                      <?php endif; ?>

                                      <td>$<?php echo e($balanceTopUp->usd); ?></td>
                                      <td><?php echo e($balanceTopUp->bdt); ?></td>

                                
                                      <td>
                                        
                                        <span class="badge bg-warning text-white w-100" style="padding: 10px;"><?php echo e($balanceTopUp->status); ?></span>
                                      </td>
                                  </tr>

                                  <?php endif; ?>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>

                            </table>
                        </div>
                    </div>
                </div>

            <div class="card">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <h5 class="mb-0">Ad Account Request</h5>
                        </div>
                        <div class="table-responsive mt-3">
                            <table id="" class="table align-middle mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th>SL</th>
                                        <th>User</th>
                                        <th>Website</th>
                                        <th>Business Manager Id</th>
                                        <th class="text-center">Status</th>
                                    </tr>
                                </thead>
                                <tbody>

                                  <?php $__currentLoopData = $adAccountRequestData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adAccount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(isset($adAccount)): ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($adAccount->userData->name); ?> (<?php echo e($adAccount->userData->userID); ?>)</td>
                                        <td><?php echo e($adAccount->website_url); ?></td>
                                        <td><?php echo e($adAccount->business_manager_id); ?></td>

                                        <td class="text-center"><span class="badge bg-warning text-white" style="padding: 10px;"> Pending </span></td>
                                        
                                    </tr>

                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>

                            </table>
                        </div>
                    </div>
                </div>


            <div class="card">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <h5 class="mb-0">Ad Account Balance TopUp Request</h5>
                        </div>
                        <div class="table-responsive mt-3">
                            <table id="" class="table align-middle mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th>SL</th>
                                        <th>User</th>
                                        <th>Ad Account</th>
                                        <th>Amount</th>
                                        <th>Note</th>
                                        <th class="text-center">Status</th>
                                    </tr>
                                </thead>
                                <tbody>

                                  <?php $__currentLoopData = $adAccountTopUpData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adAccount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(isset($adAccount)): ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($adAccount->userData->name); ?> (<?php echo e($adAccount->userData->userID); ?>)</td>
                                        <td><?php echo e($adAccount->adAccountData->ad_name); ?> (<?php echo e($adAccount->adAccountData->ad_account_number); ?>) </td>
                                        <td><?php echo e($adAccount->amount); ?></td>
                                        <td><?php echo e($adAccount->note); ?></td>

                                        <td class="text-center"><span class="badge bg-warning text-white" style="padding: 10px;"> Pending </span></td>
                                    </tr>

                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>

                            </table>
                        </div>
                    </div>
                </div>


            <div class="card">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <h5 class="mb-0">Ad Account Fund Transfer Request</h5>
                        </div>
                        <div class="table-responsive mt-3">
                            <table id="" class="table align-middle mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th>SL</th>
                                        <th>User</th>
                                        <th>From Ad Account</th>
                                        <th>Transfer Ad Account</th>
                                        <th>Amount</th>
                                        <th class="text-center">Status</th>
                                    </tr>
                                </thead>
                                <tbody>

                                  <?php $__currentLoopData = $adAccountFoundTransferData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adAccountFoundTransfer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(isset($adAccountFoundTransfer)): ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($adAccountFoundTransfer->userData->name); ?> (<?php echo e($adAccountFoundTransfer->userData->userID); ?>)</td>

                                        <td><?php echo e($adAccountFoundTransfer->fromAdAccountData->ad_name); ?> (<?php echo e($adAccountFoundTransfer->fromAdAccountData->ad_account_number); ?>)</td>

                                        <td><?php echo e($adAccountFoundTransfer->transferAdAccountData->ad_name); ?> (<?php echo e($adAccountFoundTransfer->transferAdAccountData->ad_account_number); ?>)</td>
                                        <td><?php echo e($adAccountFoundTransfer->transfer_amount); ?></td>

                                        <td class="text-center"><span class="badge bg-warning text-white" style="padding: 10px;"> Pending </span></td>
                                    </tr>

                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>

                            </table>
                        </div>
                    </div>
                </div>


            <div class="card">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <h5 class="mb-0">Service Buy Request</h5>
                        </div>
                        <div class="table-responsive mt-3">
                            <table id="" class="table align-middle mb-0">
                                <thead class="table-light">
                                    <tr>
                                        <th>SL</th>
                                        <th>User</th>
                                        <th>Service</th>
                                        <th class="text-center">Status</th>
                                    </tr>
                                </thead>
                                <tbody>

                                  <?php $__currentLoopData = $buyServiceData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buyService): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(isset($buyService)): ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($buyService->userData->name); ?> (<?php echo e($buyService->userData->userID); ?>)</td>
                                        <td><?php echo e($buyService->serviceData->name); ?></td>

                                        <td class="text-center">
                                            <span class="badge bg-warning text-white" style="padding: 10px;"> Pending </span>
                                        </td>
                                        
                                    </tr>

                                    
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>

                            </table>
                        </div>
                    </div>
                </div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\p project\gulshan-ads\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>