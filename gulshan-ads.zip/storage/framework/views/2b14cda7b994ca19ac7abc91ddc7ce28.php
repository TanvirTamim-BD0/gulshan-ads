<?php $__env->startSection('content'); ?>
	 <h6 class="mb-0 text-uppercase">Balance Report Filter</h6>
	<hr/>
	<div class="row">
		<div class="col-xl-8 mx-auto">		
			<div class="card">
              <div class="card-body">
                <div class="border p-3 rounded">
                <h6 class="mb-0 text-uppercase">Balance Report Filter</h6>
                <hr/>

                <form class="row g-3" action="<?php echo e(route('ad-account-balanace-top-up-report')); ?>" method="post">
                <?php echo csrf_field(); ?>

                  <div class="col-12">
									<label class="form-label">User</label>
										<select class="single-select" name="user_id" onchange="getAdAccount(value)" required>
											<option selected disabled>Select User</option>
											<?php $__currentLoopData = $userData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										 	 <?php if(isset($user)): ?>
											<option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?> (<?php echo e($user->userID); ?>) </option>
											<?php endif; ?>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>						
										</select>
								  </div>


								  <div class="col-12">
									<label class="form-label">Ad Account</label>
										<select class="single-select" name="ad_account_id" id="ad_account_id" required>
											<option selected disabled>Select Ad Account</option>
																	
										</select>
								  </div>

                  <div class="col-12">
                    <div class="">
                      <button type="submit" class="btn btn-primary">Filter</button>
                    </div>
                  </div>

                </form>

              </div>
              </div>
            </div>

		</div>
	</div>
	<!--end row-->


<?php $__env->stopSection(); ?>

<script>
    function getAdAccount(value) {
  
        var userId = value;
        var url = "<?php echo e(route('get-ad-account-user-wise')); ?>";
        if (userId != '') {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                type: 'post',
                url: url,
                data: {
                    userId: userId
                },
                success: function (data) {
                    //For Section...
                    $("#ad_account_id").empty();
                    $("#ad_account_id").append('<option value="" selected disabled>Select Ad Account </option>');

                    $.each(data.sectionData, function(key,value){
                        $("#ad_account_id").append('<option value="'+value.id+'">'+value.ad_name+'</option>');
                    });

                }

            });
        }
    };
  </script>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\p project\ads\ads-agency\resources\views/admin/adAccountBalanaceTopUpReport/filter.blade.php ENDPATH**/ ?>