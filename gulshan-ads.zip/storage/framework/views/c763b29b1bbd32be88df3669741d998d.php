<?php $__env->startSection('content'); ?>
	
	<div class="card bg-transparent shadow-none">
                    <div class="card-body">
                        <h6 class="mb-0 text-uppercase">Services</h6> <br>
                         
                         <form action="<?php echo e(route('services.search')); ?>" method="post">
                         <?php echo csrf_field(); ?>
                         <div class="row">
                                 <div class="col-md-8">
                                    <input type="text" class="form-control" name="serach_text" placeholder="Search Service ..">
                                 </div>
                                 <div class="col-md-1" style="margin-left: 5px;">
                                      <button class="btn btn-primary px-4 float-end">Search</button>
                                 </div>
                          </div>
                          </form>

                          <br>


                        <div class="my-3 border-top"></div>

                        <?php $__currentLoopData = $serviceCategoryData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(isset($category)): ?>
                        <a href="<?php echo e(route('service-filter',$category->id)); ?>" class="btn btn-add" style="border: 1px solid black; margin-left: 5px;"><?php echo e($category->category_name); ?></a>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <br><br>

                        <div class="card-group">
                            <div class="row">

                                <?php $__currentLoopData = $serviceData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($data): ?>
                                <div class="col-md-4" style="width: 400px;">
                                    <div class="card border-end">
                                    <img src="<?php echo e(asset('/uploads/service_image/'.$data->image)); ?>" class="card-img-top" alt="..." style="height: 250px;">
                                    <div class="card-body">
                                        <h5 class="card-title"><?php echo e($data->name); ?></h5>
                                        <h6><?php echo e($data->serviceCategoryData->category_name); ?></h6>
                                        
                                        <h5>$<?php echo e($data->price); ?></h5>
                                        <a href="<?php echo e(route('buy-service',$data->id)); ?>" class="btn btn-success">Buy Now</a>
                                        <a href="<?php echo e(route('service-details',$data->id)); ?>" class="btn btn-primary">Read More...</a>
                                    </div>
                                </div>
                                </div>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>

                            
                        </div>
                    </div>
                </div>

                 <nav class="float-end mt-4" aria-label="Page navigation">
                  <ul class="pagination">

                    <?php echo e($serviceData->links('user.paginate')); ?>



                  </ul>
                </nav>
                
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\p project\ads\ads-agency\resources\views/user/services.blade.php ENDPATH**/ ?>