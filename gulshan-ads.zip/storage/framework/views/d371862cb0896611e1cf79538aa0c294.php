<?php $__env->startSection('content'); ?>
    <h6 class="mb-0 text-uppercase">Service Buy Request</h6>
				<hr/>

				<div class="card">
					<div class="card-body">
						<div class="table-responsive">
							<table id="example" class="table table-striped table-bordered" style="width:100%">
								<thead>
									<tr>
										<th>SL</th>
										<th>User</th>
										<th>Service</th>
										<th>Exist Balance</th>
										<th>Service Amount</th>
										<th>Date</th>
										<th class="text-center">Status</th>
										<th>Action</th>
									</tr>
								</thead>
								<tbody>

									<?php $__currentLoopData = $buyServiceData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buyService): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php if(isset($buyService)): ?>
									<tr>
										<td><?php echo e($loop->iteration); ?></td>
										<td><?php echo e($buyService->userData->name); ?> (<?php echo e($buyService->userData->userID); ?>)</td>
										<td><?php echo e($buyService->serviceData->name); ?></td>
										<td><?php echo e($buyService->userData->balance); ?></td>
										<td><?php echo e($buyService->serviceData->price); ?></td>
										<td><?php echo e($buyService->created_at); ?></td>

										<td class="text-center">
											<?php if($buyService->status == 'Confirmed'): ?>
											<span class="badge bg-success text-white" style="padding: 10px;"> Confirmed </span>
											<?php elseif($buyService->status == 'Reject'): ?>
											<span class="badge bg-danger text-white" style="padding: 10px;"> Reject </span>
											<?php else: ?>
											<span class="badge bg-warning text-white" style="padding: 10px;"> Pending </span>
											<?php endif; ?>
										</td>
										
										<td>
				                            <?php if($buyService->status == 'Confirmed'): ?>
				                        	<?php else: ?>
				                            <a href="javascript:;" data-bs-toggle="modal"
	                                        data-bs-target="#confirmedData<?php echo e($buyService->id); ?>"  class="text-success" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Reject"><i class="bi bi-check-circle"></i> Confirmed</a><br>
				                            <?php endif; ?>
 
				                            <?php if($buyService->status == 'Reject'): ?>
				                            <?php else: ?>
				                            <a href="javascript:;" data-bs-toggle="modal"
	                                        data-bs-target="#rejectedData<?php echo e($buyService->id); ?>"  class="text-danger" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Reject"><i class="bi bi-file-earmark-x"></i> Reject</a><br>
	                                        <?php endif; ?>

	                                        <a href="<?php echo e(route('service-buy-request-delete',$buyService->id)); ?>" class="text-danger" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Delete"><i class="bi bi-archive-fill"></i> Delete</a><br>
	                                        
				                         </td>

									</tr>

									<!-- Confirmed Text -->
                                    <div class="modal fade" id="confirmedData<?php echo e($buyService->id); ?>" tabindex="-1"
                                        aria-labelledby="usd_detailsLabel" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <form action="<?php echo e(route('service-buy-request-confirmed',$buyService->id)); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="service_buy_id" value="<?php echo e($buyService->id); ?>">
                                               	<div class="modal-header">
                                                    <h5 class="modal-title" id="usd_detailsLabel">Text</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                        aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="row">
                                                        <div class="col-md-12 col-lg-12">
                                                            	<textarea class="form-control" cols="20" rows="5" name="confirmed_text">
                                                            		
                                                            	</textarea>
                                                        </div>
                                                        
                                                    </div>
                                                </div>

                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary"
                                                        data-bs-dismiss="modal">Close</button>
                                                     <button type="submit" class="btn btn-primary"
                                                        data-bs-dismiss="modal">Submit</button>
                                                </div>

                                                </form>
                                            </div>
                                        </div>
                                    </div>

									<!-- Rejected Text -->
                                    <div class="modal fade" id="rejectedData<?php echo e($buyService->id); ?>" tabindex="-1"
                                        aria-labelledby="usd_detailsLabel" aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <form action="<?php echo e(route('service-buy-request-reject',$buyService->id)); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="service_buy_id" value="<?php echo e($buyService->id); ?>">
                                               	<div class="modal-header">
                                                    <h5 class="modal-title" id="usd_detailsLabel">Rejected Text</h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                        aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="row">
                                                        <div class="col-md-12 col-lg-12">
                                                            	<textarea class="form-control" cols="20" rows="5" name="rejected_text">
                                                            		
                                                            	</textarea>
                                                        </div>
                                                        
                                                    </div>
                                                </div>

                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary"
                                                        data-bs-dismiss="modal">Close</button>
                                                     <button type="submit" class="btn btn-primary"
                                                        data-bs-dismiss="modal">Submit</button>
                                                </div>

                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                    
									<?php endif; ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

									
									
									
								</tbody>
								
							</table>
						</div>
					</div>
				</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\p project\ads\ads-agency\resources\views/admin/services/buyServiceList.blade.php ENDPATH**/ ?>